<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="house" tilewidth="128" tileheight="192" tilecount="1" columns="1">
 <image source="../Assets/Buildings/House1.png" width="128" height="192"/>
</tileset>
