<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="goldStone2" tilewidth="128" tileheight="128" tilecount="6" columns="6">
 <image source="../Assets/Terrain/Resources/Gold/Gold Stones/Gold Stone 2_Highlight.png" width="768" height="128"/>
 <tile id="0">
  <animation>
   <frame tileid="0" duration="100"/>
   <frame tileid="1" duration="100"/>
   <frame tileid="2" duration="100"/>
   <frame tileid="3" duration="100"/>
   <frame tileid="4" duration="100"/>
   <frame tileid="5" duration="100"/>
  </animation>
 </tile>
</tileset>
