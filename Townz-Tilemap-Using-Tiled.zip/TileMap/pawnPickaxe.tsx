<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="pawnPickaxe" tilewidth="192" tileheight="192" tilecount="6" columns="6">
 <image source="../Assets/Units/Pawn/Pawn_Interact Pickaxe.png" width="1152" height="192"/>
 <tile id="0">
  <animation>
   <frame tileid="0" duration="100"/>
   <frame tileid="1" duration="100"/>
   <frame tileid="2" duration="100"/>
   <frame tileid="3" duration="100"/>
   <frame tileid="4" duration="100"/>
  </animation>
 </tile>
</tileset>
